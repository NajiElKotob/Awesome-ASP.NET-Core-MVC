﻿using MvcJQueryAjaxDEMO.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace MvcJQueryAjaxDEMO.Controllers.API
{
    public class DeliveryMenuController : ApiController
    {

        List<DeliveryMenu> items = new List<DeliveryMenu>() {
                    new DeliveryMenu {ID = 1, Name = "Starters" },
                    new DeliveryMenu {ID = 2, Name= "Salads" },
                    new DeliveryMenu {ID = 3, Name = "Sandwiches" },
                    new DeliveryMenu {ID = 4, Name = "Platters" },
                    new DeliveryMenu {ID = 5, Name = "Pasta" },
                    new DeliveryMenu {ID = 6, Name = "Angus Beef Burgers" },
                    new DeliveryMenu {ID = 7, Name ="Burgers and 220's" },
                    new DeliveryMenu {ID = 8, Name = "Desserts" },
                    new DeliveryMenu {ID = 9, Name ="Drinks" }
                    };

        // GET: api/DeliveryMenu
        public IHttpActionResult Get()
        {
            //return new JavaScriptSerializer().Serialize(items);
            System.Threading.Thread.Sleep(2000);
            return Ok(items);
        }

        // GET: api/DeliveryMenu/5
        public IHttpActionResult Get(int id)
        {
            return Ok(items.Single(i => i.ID == id));
        }

        // POST: api/DeliveryMenu
        [HttpPost]
        public IHttpActionResult Post(DeliveryMenu value)
        {
            //items.Add(new DeliveryMenu() { ID = value.ID, Name = value.Name });
            items.Add(value);
            return Ok();
        }

        // PUT: api/DeliveryMenu/5
        [HttpPut]
        public IHttpActionResult Put(int id, DeliveryMenu value)
        {
            var item = items.Single(i => i.ID == id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                item.Name = value.Name;
            }

            return Ok();
        }

        // DELETE: api/DeliveryMenu/5
        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            var item = items.Single(i => i.ID == id);
            if (item == null)
            {
                return NotFound();
            }
            else
            {
                items.Remove(item);
            }

            return Ok();
        }
    }
}
