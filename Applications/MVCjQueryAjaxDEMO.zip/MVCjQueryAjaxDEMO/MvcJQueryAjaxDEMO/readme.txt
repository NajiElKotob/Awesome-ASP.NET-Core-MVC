﻿https://haacked.com/archive/2011/06/30/whatrsquos-the-difference-between-a-value-provider-and-model-binder.aspx/
http://www.c-sharpcorner.com/article/call-web-api-using-jquery-ajax-in-asp-net-core/ **
http://www.dotnetodyssey.com/2015/01/14/autocomplete-textbox-using-jquery-asp-net-querying-database-complete-example/

Advanced
https://andrewlock.net/formatting-response-data-as-xml-or-json-based-on-the-url-in-asp-net-core/

Templating
jQuery http://stephenwalther.com/archive/2010/11/30/an-introduction-to-jquery-templates (For testing and simulation only, don't use it in real projects)
https://github.com/BorisMoore/jquery-tmpl

