https://github.com/NajiElKotob/Awesome-EntityFrameworkCore
https://github.com/NajiElKotob/Awesome-ASP.NET-Core-MVC