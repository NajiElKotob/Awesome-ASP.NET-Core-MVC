﻿using DevAcademy.Domain;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;

namespace DevAcademy.Data
{
    public class DevAcacemyContext : IdentityDbContext
    {
        public DevAcacemyContext(DbContextOptions<DevAcacemyContext> options)
        : base(options)
        {
        }
        public DbSet<Course> Courses { get; set; }
    }
}
