﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication17.Controllers
{
    
    
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        [Route("/company")]
        [Route("/about")]
        [Route("home/about")]

        public IActionResult About()
        {
            return View();
        }
    }
}
